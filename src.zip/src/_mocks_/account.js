// ----------------------------------------------------------------------

const account = {
  displayName: 'Patricode',
  email: 'partrick@gmail.com',
  photoURL: '/static/mock-images/avatars/avatar_default.jpg'
};

export default account;
